#!/bin/bash
echo "Long Running Job is beginning"
echo "My Job is to Sleep"
echo "Now am going to Sleep for $1 Seconds"
sleep $1
exit
